command line package to calculate Topsis Score and Rank 
